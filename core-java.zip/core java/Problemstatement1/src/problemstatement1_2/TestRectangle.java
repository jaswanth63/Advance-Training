package problemstatement1_2;
public class TestRectangle {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle();
		r1.userinput();
		r1.area();
		r1.details();
		Rectangle r2 = new Rectangle();
		r2.userinput();
		r2.area();
		r2.details();
		Rectangle r3 = new Rectangle();
		r3.userinput();
		r3.area();
		r3.details();
		Rectangle r4 = new Rectangle();
		r4.userinput();
		r4.area();
		r4.details();
		Rectangle r5 = new Rectangle();
		r5.userinput();
		r5.area();
		r5.details();
		

	}

}
